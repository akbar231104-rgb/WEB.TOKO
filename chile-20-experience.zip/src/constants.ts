export interface Product {
  id: string;
  name: string;
  description: string;
  subDescription: string;
  image: string;
  color: string;
  accentColor: string;
}

export const PRODUCTS: Product[] = [
  {
    id: "black",
    name: "CHILE 20 BLACK",
    description: "Lightweight insulation making it for speed and heat.",
    subDescription: "Born from the streets.",
    image: "/src/assets/images/black_adidas_jacket_1779183693017.png",
    color: "#000000",
    accentColor: "#FF4D00"
  },
  {
    id: "red",
    name: "CHILE 20 RED",
    description: "Essential, easy-access storage to keep you moving.",
    subDescription: "Weather-resistant wet look.",
    image: "/src/assets/images/red_adidas_jacket_1779183673421.png",
    color: "#FF4D00",
    accentColor: "#F2F2F2"
  },
  {
    id: "white",
    name: "CHILE 20 WHITE",
    description: "The power to create.",
    subDescription: "Premium materials for everyday comfort.",
    image: "/src/assets/images/white_adidas_jacket_1779183711112.png",
    color: "#FFFFFF",
    accentColor: "#FF4D00"
  }
];
