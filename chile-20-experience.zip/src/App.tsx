/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useCallback, useMemo } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import Header from './components/Header';
import { PRODUCTS, Product } from './constants';
import Carousel from './components/Carousel';
import DetailView from './components/DetailView';
import { ShoppingBag, Search, Menu, X } from "lucide-react";

export default function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [personalizeName, setPersonalizeName] = useState("");
  const [isPersonalizing, setIsPersonalizing] = useState(false);

  const handleProductSelect = useCallback((product: Product) => {
    setSelectedProduct(product);
  }, []);

  const handleBack = useCallback(() => {
    setSelectedProduct(null);
    setIsPersonalizing(false);
  }, []);

  const handleOpenPersonalize = useCallback(() => {
    setIsPersonalizing(true);
  }, []);

  const handleClosePersonalize = useCallback(() => {
    setIsPersonalizing(false);
  }, []);

  const backgroundText = useMemo(() => {
    if (isPersonalizing && personalizeName) {
      return personalizeName.toUpperCase();
    }
    return "CHILE 20";
  }, [isPersonalizing, personalizeName]);

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden font-sans select-none">
      <Header />
      
      {/* Background large text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden">
        <motion.h1 
          key={backgroundText}
          initial={{ opacity: 0, scale: 0.9, rotateX: -10 }}
          animate={{ opacity: 0.05, scale: 1, rotateX: 0, x: selectedProduct ? "-20%" : "0%" }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
          className="text-[35vw] font-display uppercase whitespace-nowrap leading-none tracking-tighter"
        >
          {backgroundText} {backgroundText}
        </motion.h1>
      </div>

      {/* Grid Lines Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] z-0">
        <div className="w-full h-full border-x border-white/20 mx-auto max-w-7xl relative">
          <div className="absolute top-1/2 left-0 w-full h-[1px] bg-white/20" />
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!selectedProduct ? (
          <motion.div
            key="carousel"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.8 }}
            className="w-full h-full"
          >
            <Carousel 
              products={PRODUCTS} 
              onSelect={handleProductSelect}
              currentIndex={currentIndex}
              setCurrentIndex={setCurrentIndex}
            />
          </motion.div>
        ) : (
          <motion.div
            key="detail"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-full"
          >
            <DetailView 
              product={selectedProduct} 
              onBack={handleBack} 
              onPersonalize={handleOpenPersonalize}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Personalization Overlay */}
      <AnimatePresence>
        {isPersonalizing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center p-8 backdrop-blur-3xl bg-opacity-95"
          >
             <button 
              onClick={handleClosePersonalize}
              className="absolute top-12 right-12 p-4 rounded-full border border-white/20 hover:bg-white/10 transition-colors"
            >
              <X size={24} />
            </button>

            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-center flex flex-col gap-8 w-full max-w-2xl"
            >
              <span className="text-[10px] uppercase font-bold tracking-[0.6em] text-red-500">The Power to Create</span>
              <h2 className="text-4xl font-display uppercase tracking-tighter">Your Legacy</h2>
              
              <div className="relative group">
                <input 
                  type="text" 
                  value={personalizeName}
                  onChange={(e) => setPersonalizeName(e.target.value)}
                  placeholder="TYPE YOUR NAME..."
                  className="w-full bg-transparent border-b-2 border-white/20 py-6 px-4 text-6xl font-display uppercase tracking-widest text-center focus:outline-none focus:border-red-500 transition-colors placeholder:opacity-20"
                  autoFocus
                />
              </div>

              <p className="text-sm opacity-40 font-light tracking-widest uppercase">
                {personalizeName ? "Click share to join the collective" : "Begin typing to personalize your experience"}
              </p>

              <div className="flex justify-center gap-6 mt-12">
                <button 
                  onClick={handleClosePersonalize}
                  className="px-12 py-4 rounded-full border border-white/20 uppercase text-[10px] font-bold tracking-widest hover:bg-white hover:text-black transition-all"
                >
                  Share Now
                </button>
              </div>
            </motion.div>

            {/* Giant Preview Name */}
            <h1 className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[40vw] font-display uppercase opacity-[0.03] -z-10 whitespace-nowrap pointer-events-none">
              {personalizeName || "CHILE 20"}
            </h1>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Progress Indicator */}
      {!selectedProduct && !isPersonalizing && (
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 flex items-center gap-12 z-40">
          <div className="text-[10px] uppercase font-bold tracking-[0.3em] opacity-40">01</div>
          <div className="relative w-48 h-[1px] bg-white/20">
            <motion.div 
              className="absolute top-0 left-0 h-full bg-white"
              animate={{ width: `${((currentIndex + 1) / PRODUCTS.length) * 100}%` }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            />
          </div>
          <div className="text-[10px] uppercase font-bold tracking-[0.3em] opacity-40">0{PRODUCTS.length}</div>
        </div>
      )}

      {/* Footer Meta */}
      {!isPersonalizing && (
        <>
          <div className="fixed bottom-12 left-12 flex gap-12 z-40 text-[10px] uppercase font-bold tracking-[0.3em] opacity-40 hidden md:flex">
            <span>© 2024 ADIDAS AS</span>
            <span>SCROLL TO EXPLORE</span>
          </div>
          
          <div className="fixed bottom-12 right-12 z-40 text-[10px] uppercase font-bold tracking-[0.3em] opacity-40 hidden md:flex">
            <span>SELECT A PRODUCT TO BEGIN</span>
          </div>
        </>
      )}
    </div>
  );
}
