import { motion, useMotionValue, useSpring, useTransform } from "motion/react";
import { useEffect, useRef } from "react";
import { Product } from "../constants";

interface CarouselProps {
  products: Product[];
  onSelect: (product: Product) => void;
  currentIndex: number;
  setCurrentIndex: (index: number) => void;
}

export default function Carousel({ products, onSelect, currentIndex, setCurrentIndex }: CarouselProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const springX = useSpring(x, { stiffness: 100, damping: 20 });

  useEffect(() => {
    // Center the current card
    const centerOffset = (currentIndex * -400); // 400 is approx width + gap
    x.set(centerOffset);
  }, [currentIndex, x]);

  const handleNext = () => {
    if (currentIndex < products.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  // Add scroll listener
  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      if (Math.abs(e.deltaY) < 10) return; // Prevent accidental scrolls
      
      if (e.deltaY > 0) {
        handleNext();
      } else {
        handlePrev();
      }
    };

    window.addEventListener('wheel', handleWheel);
    return () => window.removeEventListener('wheel', handleWheel);
  }, [currentIndex]); // Re-bind on index change

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center pt-24 overflow-hidden">
      <motion.div 
        ref={containerRef}
        style={{ x: springX }}
        className="flex gap-12 px-[20%] items-center"
      >
        {products.map((product, index) => (
          <CarouselItem 
            key={product.id}
            product={product}
            isActive={index === currentIndex}
            onClick={() => {
              if (index === currentIndex) {
                onSelect(product);
              } else {
                setCurrentIndex(index);
              }
            }}
          />
        ))}
      </motion.div>

      {/* Navigation Controls */}
      <div className="absolute top-1/2 left-0 w-full -translate-y-1/2 flex justify-between px-12 pointer-events-none">
        <button 
          onClick={handlePrev}
          disabled={currentIndex === 0}
          className={`w-16 h-16 rounded-full border border-white/20 flex items-center justify-center pointer-events-auto transition-all ${currentIndex === 0 ? 'opacity-0' : 'hover:scale-110 hover:bg-white/10'}`}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <button 
          onClick={handleNext}
          disabled={currentIndex === products.length - 1}
          className={`w-16 h-16 rounded-full border border-white/20 flex items-center justify-center pointer-events-auto transition-all ${currentIndex === products.length - 1 ? 'opacity-0' : 'hover:scale-110 hover:bg-white/10'}`}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6"/></svg>
        </button>
      </div>
    </div>
  );
}

function CarouselItem({ product, isActive, onClick }: { product: Product; isActive: boolean; onClick: () => void }) {
  return (
    <motion.div
      onClick={onClick}
      animate={{ 
        scale: isActive ? 1.2 : 0.7,
        opacity: isActive ? 1 : 0.3,
        z: isActive ? 100 : 0,
        rotateY: isActive ? 0 : (isActive ? 0 : 25)
      }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className="relative w-[400px] h-[500px] flex-shrink-0 cursor-pointer flex flex-col items-center justify-center group"
      style={{ perspective: "1000px" }}
    >
      {/* Product Image */}
      <motion.div
        className="relative w-full h-full flex items-center justify-center"
        animate={{ 
          y: isActive ? [0, -10, 0] : 0
        }}
        transition={{ 
          duration: 4, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
      >
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-contain drop-shadow-[0_40px_60px_rgba(0,0,0,0.6)]"
        />
        
        {/* Glow behind product */}
        {isActive && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 0.3, scale: 1.2 }}
            className="absolute inset-x-0 bottom-1/4 h-1/2 -z-10 blur-[100px] rounded-full"
            style={{ backgroundColor: product.accentColor }}
          />
        )}
      </motion.div>

      {/* Brand ID Badge (matches video) */}
      {isActive && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute -bottom-8 flex flex-col items-center"
        >
          <div className="w-[1px] h-12 bg-brand/40 mb-4" />
          <h2 className="text-3xl font-display uppercase tracking-widest leading-tight">{product.name}</h2>
          <p className="mono-label !opacity-100 !text-brand mt-2">Active_Link / Detail_View</p>
        </motion.div>
      )}
    </motion.div>
  );
}
