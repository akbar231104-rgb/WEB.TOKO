import { motion } from "motion/react";
import { ArrowLeft, Play, Volume2 } from "lucide-react";
import { Product } from "../constants";

interface DetailViewProps {
  product: Product;
  onBack: () => void;
  onPersonalize: () => void;
}

export default function DetailView({ product, onBack, onPersonalize }: DetailViewProps) {
  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
      {/* Background large text for this specific product */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10 select-none">
        <motion.h1 
          initial={{ x: "20%" }}
          animate={{ x: "-10%" }}
          transition={{ duration: 15, repeat: Infinity, repeatType: "mirror", ease: "linear" }}
          className="text-[40vw] font-display uppercase whitespace-nowrap leading-none tracking-tighter"
        >
          {product.name.split(' ')[2]} {product.name.split(' ')[2]}
        </motion.h1>
      </div>

      <div className="container mx-auto px-12 h-screen flex flex-col md:flex-row items-center justify-between relative z-10">
        
        {/* Left Side: Descriptive Text */}
        <div className="w-full md:w-1/2 flex flex-col justify-center gap-16 pt-24 md:pt-0">
          <motion.div 
             initial={{ opacity: 0, x: -50 }}
             animate={{ opacity: 1, x: 0 }}
             transition={{ duration: 0.8 }}
             className="flex flex-col gap-6"
          >
            <div className="flex gap-4 items-center">
              <span className="mono-label !text-brand !opacity-100">Catalog.Ref / {product.id.toUpperCase()}_v4</span>
              <div className="w-8 h-[1px] bg-brand" />
            </div>
            <h2 className="text-huge">
              {product.description.split(',')[0]}<br/>
              <span className="text-brand">{product.description.split(',')[1] || "CHILE 20"}</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 border-l-2 border-brand pl-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col gap-6"
            >
              <p className="text-lg font-light leading-relaxed opacity-60">
                {product.subDescription} Sebuah inovasi dalam tekstil dan kenyamanan premium, dirancang untuk kecepatan dan performa maksimal.
              </p>
              <div className="flex items-center gap-6">
                <button className="bg-brand text-white px-10 py-5 font-black uppercase tracking-widest text-[11px] hover:bg-white hover:text-black transition-all">
                  Access_Vault ( )
                </button>
                <button 
                  onClick={onPersonalize}
                  className="px-10 py-5 border border-white/20 font-black uppercase tracking-widest text-[10px] hover:bg-brand transition-all"
                >
                  Create_Legacy
                </button>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              transition={{ delay: 0.8 }}
              className="flex flex-col gap-4 text-[10px] uppercase font-mono tracking-widest"
            >
              <div className="flex justify-between border-b border-white/10 pb-2">
                <span>Material_Depth</span>
                <span>0.99A</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-2">
                <span>Thermal_Index</span>
                <span>STABLE</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-2">
                <span>Origin_Node</span>
                <span>DEPR_LAB_01</span>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Right Side: Product Image with Floating Animation */}
        <div className="w-full md:w-1/2 flex items-center justify-center relative">
          <motion.div
            layoutId={product.id}
            initial={{ scale: 0.8, opacity: 0, rotate: -10 }}
            animate={{ scale: 1.2, opacity: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 50, damping: 15 }}
            className="relative"
          >
            <motion.img 
              src={product.image} 
              alt={product.name}
              className="w-full h-auto max-h-[70vh] object-contain drop-shadow-[0_50px_100px_rgba(0,0,0,0.8)]"
              animate={{ 
                y: [0, -20, 0],
                rotate: [0, 2, 0]
              }}
              transition={{ 
                duration: 6, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
            />
            {/* Glow effect */}
            <div 
              className="absolute inset-0 bg-red-600/20 blur-[120px] rounded-full -z-10" 
              style={{ backgroundColor: `${product.accentColor}20` }}
            />
          </motion.div>
        </div>
      </div>

      {/* Back Button */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        onClick={onBack}
        className="fixed top-32 left-12 flex items-center gap-4 mono-label hover:text-brand transition-colors z-50 group pointer-events-auto"
      >
        <div className="w-10 h-[1px] bg-white/20 group-hover:bg-brand group-hover:w-16 transition-all" />
        Return_Home
      </motion.button>

      {/* Detail Controls (Bottom) */}
      <div className="fixed bottom-12 right-12 flex items-center gap-6 text-[10px] uppercase font-bold tracking-[0.2em] z-40 opacity-40">
        <Volume2 size={16} />
        <span>Chile 20 Experience</span>
      </div>
    </div>
  );
}
