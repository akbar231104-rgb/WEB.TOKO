import { motion } from "motion/react";
import { ShoppingBag, Search, Menu } from "lucide-react";

export default function Header() {
  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="fixed top-0 left-0 w-full z-50 px-12 py-8 flex justify-between items-baseline border-b border-white/10 bg-bg-dark/80 backdrop-blur-md pointer-events-none"
    >
      <div className="flex items-center gap-8 pointer-events-auto">
        <div className="flex items-center gap-6">
           <span className="mono-label">System.Core / Adidas_Archive</span>
           <div className="flex gap-2 items-center">
            <div className="w-2 h-2 rounded-full bg-brand animate-pulse"></div>
            <span className="text-[10px] font-mono tracking-widest opacity-40">CHILE20_STABLE</span>
          </div>
        </div>
      </div>

      <div className="flex items-baseline gap-12 pointer-events-auto">
        <nav className="hidden md:flex gap-10 text-[11px] font-black uppercase tracking-widest">
          <a href="#" className="hover:text-brand transition-colors">Catalog</a>
          <a href="#" className="hover:text-brand transition-colors">Lab</a>
          <a href="#" className="hover:text-brand transition-colors">Protocol</a>
        </nav>
        
        <div className="flex items-center gap-8">
          <button className="hidden md:block text-[10px] font-mono font-bold tracking-widest uppercase border-l border-white/20 pl-8 hover:text-brand transition-colors">
            Initiate_Purchase ( )
          </button>
          <div className="flex items-center gap-6">
            <Search size={18} className="cursor-pointer hover:text-brand transition-all" />
            <ShoppingBag size={18} className="cursor-pointer hover:text-brand transition-all" />
          </div>
        </div>
      </div>
    </motion.header>
  );
}
